# org.json.me
Java ME Library for JSON
